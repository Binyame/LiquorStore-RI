<?php

require_once 'custom-post-type-taxonomy.php';
require_once 'custom-post-type.php';
require_once 'custom-post-types.php';