<?php

get_header();

// Include content template
aperitif_template_part( 'content', 'templates/content', 'search' );

get_footer();