<?php

// Include logo
aperitif_template_part( 'header', 'templates/parts/logo' );

// Include main navigation
aperitif_template_part( 'header', 'templates/parts/navigation' );