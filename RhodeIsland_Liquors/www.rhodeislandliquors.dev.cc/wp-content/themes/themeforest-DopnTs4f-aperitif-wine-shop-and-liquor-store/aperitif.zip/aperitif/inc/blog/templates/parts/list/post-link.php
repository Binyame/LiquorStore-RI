<article <?php post_class( 'qodef-blog-item qodef-e' ); ?>>
	<div class="qodef-e-inner">
		<?php
		// Include post format part
		aperitif_template_part( 'blog', 'templates/parts/post-format/link' ); ?>
	</div>
</article>