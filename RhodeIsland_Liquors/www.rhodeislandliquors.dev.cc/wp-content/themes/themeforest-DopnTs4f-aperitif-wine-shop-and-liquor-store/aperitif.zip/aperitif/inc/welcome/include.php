<?php

include_once APERITIF_INC_ROOT_DIR . '/welcome/welcome.php';