<a itemprop="url" class="qodef-header-logo-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
	<?php
	// Include header logo image html
	echo aperitif_get_header_logo_image(); ?>
</a>