<?php

include_once 'class-tgm-plugin-activation.php';
include_once 'plugins-activation.php';