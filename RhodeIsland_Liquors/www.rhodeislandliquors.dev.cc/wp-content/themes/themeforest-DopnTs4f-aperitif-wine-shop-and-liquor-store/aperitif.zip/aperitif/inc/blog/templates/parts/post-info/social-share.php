<?php

$params                      = array();
$params['layout']            = 'dropdown';
$params['dropdown_behavior'] = 'left';

echo AperitifCoreSocialShareShortcode::call_shortcode( $params );