<?php

// Include mobile logo
aperitif_template_part( 'mobile-header', 'templates/parts/mobile-logo' );

// Include mobile navigation opener
aperitif_template_part( 'mobile-header', 'templates/parts/mobile-navigation-opener' );

// Include mobile navigation
aperitif_template_part( 'mobile-header', 'templates/parts/mobile-navigation' );