<?php

// Hook to include page title template
do_action( 'aperitif_action_page_title_template' );