<?php

define( 'APERITIF_ROOT', get_template_directory_uri() );
define( 'APERITIF_ROOT_DIR', get_template_directory() );
define( 'APERITIF_ASSETS_ROOT', APERITIF_ROOT . '/assets' );
define( 'APERITIF_ASSETS_ROOT_DIR', APERITIF_ROOT_DIR . '/assets' );
define( 'APERITIF_ASSETS_CSS_ROOT', APERITIF_ASSETS_ROOT . '/css' );
define( 'APERITIF_ASSETS_CSS_ROOT_DIR', APERITIF_ASSETS_ROOT_DIR . '/css' );
define( 'APERITIF_ASSETS_JS_ROOT', APERITIF_ASSETS_ROOT . '/js' );
define( 'APERITIF_ASSETS_JS_ROOT_DIR', APERITIF_ASSETS_ROOT_DIR . '/js' );
define( 'APERITIF_INC_ROOT', APERITIF_ROOT . '/inc' );
define( 'APERITIF_INC_ROOT_DIR', APERITIF_ROOT_DIR . '/inc' );
