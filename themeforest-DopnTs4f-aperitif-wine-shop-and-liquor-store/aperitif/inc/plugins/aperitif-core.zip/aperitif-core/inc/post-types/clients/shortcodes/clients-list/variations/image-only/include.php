<?php

include_once 'image-only.php';
include_once 'hover-animations/include.php';