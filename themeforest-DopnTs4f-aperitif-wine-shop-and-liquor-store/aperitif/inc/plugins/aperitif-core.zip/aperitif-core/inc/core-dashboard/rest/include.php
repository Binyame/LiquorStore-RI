<?php

include_once APERITIF_CORE_INC_PATH . '/core-dashboard/rest/rest.php';