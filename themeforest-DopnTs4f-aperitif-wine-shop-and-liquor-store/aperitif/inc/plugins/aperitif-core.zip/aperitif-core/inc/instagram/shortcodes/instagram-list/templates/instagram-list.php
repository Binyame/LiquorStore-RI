<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php echo do_shortcode( "[instagram-feed $instagram_params]" ); // XSS OK ?>
</div>