<a itemprop="url" class="qodef-e-post-link" href="<?php the_permalink(); ?>"
   title="<?php the_title_attribute(); ?>"></a>