<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-m-inner">
		<?php aperitif_core_template_part( 'shortcodes/call-to-action', 'templates/parts/content', '', $params ) ?>
		<?php aperitif_core_template_part( 'shortcodes/call-to-action', 'templates/parts/button', '', $params ) ?>
	</div>
</div>