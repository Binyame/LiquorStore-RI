<?php

if ( $icon_type == 'icon-pack' ) {
	echo AperitifCoreIconShortcode::call_shortcode( $icon_params );
}