<?php
if ( ! empty( $button_params ) ) { ?>
	<div class="qodef-m-button">
		<?php echo AperitifCoreButtonShortcode::call_shortcode( $button_params ); ?>
	</div>
<?php }