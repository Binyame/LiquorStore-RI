<a href="#" class="qodef-login-opener qodef-login">
	<span class="qodef-login-opener-text"><?php esc_html_e('Login', 'aperitif-membership'); ?></span>
	<span class="qodef-login-icon lnr-user lnr" style=""></span>
</a>
<a href="#" class="qodef-login-opener qodef-register">
	<span class="qodef-login-opener-text"><?php esc_html_e('Register', 'aperitif-membership'); ?></span>
	<span class="qodef-login-icon lnr-pencil lnr" style=""></span>
</a>