<?php

require_once APERITIF_MEMBERSHIP_INC_PATH . '/general/register-template.php';
include_once APERITIF_MEMBERSHIP_INC_PATH . '/general/helper.php';