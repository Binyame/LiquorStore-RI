<div class="qodef-m-social-login-holder">
	<?php do_action( 'aperitif_membership_action_social_login_content' ); ?>
</div>